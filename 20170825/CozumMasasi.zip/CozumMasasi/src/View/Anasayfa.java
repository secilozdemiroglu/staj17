
package View;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controller.ProblemsController;
import Controller.TagsController;
import Entity.Problem;
import Entity.Tag;

/**
 * Servlet implementation class Anasayfa
 */
@WebServlet("/index.html")
public class Anasayfa extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Anasayfa() {
        super();
        // TODO Auto-generated constructor stub
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		String kelime= null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy, EEEE");
        String currentDate = sdf.format(new Date());
	
//        int id = Integer.parseInt(request.getParameter("id"));
        
		PrintWriter out = response.getWriter();
		ProblemsController pc = new ProblemsController();
		TagsController tc = new TagsController();

		ArrayList<Problem> result = pc.readAll();
		ArrayList<Problem> resultlast = pc.readlast();
//		ArrayList<Problem> resultinstantprob = pc.searchInstant(kelime);
		HashMap<String,Integer> resultcounterror = pc.statisticErrors();
		ArrayList<Tag> resultlasttag = tc.readlast();

		out.println("<html><head>"
				
				+ "<!-- CSS FOLDERS -->"
				+ "<link href='plugins/bootstrap/css/bootstrap.min.css' rel='stylesheet'>"
				+ "<link href='plugins/font-awesome/css/font-awesome.min.css' rel='stylesheet'>"
				+ "<link href='plugins/owl-carousel/assets/owl.carousel.css' rel='stylesheet'>"
				+ "<link href='plugins/owl-carousel/assets/owl.theme.default.css' rel='stylesheet'>"
				+ "<link href='plugins/style.css' rel='stylesheet'>"
				
				+ "<!-- JS FOLDERS -->"
				+ "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>"
				+ "<script src='plugins/owl-carousel/owl.carousel.min.js' rel='stylesheet'></script>"
				+ "<script src='plugins/bootstrap/js/bootstrap.min.js'></script>");
		
out.print("<script>"
				

				+	"function addFunction(problemdeger,cozumdeger) {\n"
				+	"var ekrandanGelenProblem = $('#' + problemdeger).val();\n"
				+	"var ekrandanGelenCozum = $('#' + cozumdeger).val();\n"
				
			   +" if ( ekrandanGelenProblem==''){"
		 		+"alert(\"HATA BO� BIRAKILAMAZ\");}"			 		
			    +"else if (ekrandanGelenProblem.length <= 20 ){"
		 		+"alert(\"HATA 20 KARAKTERDEN K���K OLAMAZ\");}else{"
			    
				+	"$.post('AddProblem', {\n"
				 		+	"gelenprob: ekrandanGelenProblem,"
				 		+ 	"gelencozum:ekrandanGelenCozum\n"				 	
				 		+	"},\n"
				 		+	"function(result){"
				 		+ "if (cozumdeger==\"\"){alert(\"PROBLEM�N ��Z�M� YOK\");}"				 		
				 		+"alert(\"KAYIT YAPILDI\");"			 		
				 		+	"},\n"
				 		
				 +	")}; }\n\n\n"
				 								
				+ "</script>");
		
		
		out.println("</head><body>");
		out.println("<div style='height:10px; width:100%; background-color:#004892;'></div>");
		out.println("<div class='container' style='margin-top:20px;'>"
					+ "<div class='row'>"
						+ "<div class='col-md-4'>"
							+ "<a href='index.html'><img src='Images/cozummasasilogo.png' style='width:350px; height:auto;'></a>"
						+ "</div>"

						+ "<div class='col-md-6' style='margin-top:20px;'>"
						+ "<form action='DetaySearch' method='GET'>"

						+ "<div class='input-group'>"

						+ "<input type='text' class='form-control input-lg' placeholder='Problem, ��z�m ve ya etiket aray�n' name='search'>"
						
								+ "<span class='input-group-btn' style='width:175px;'>"
								+ "<select name='cat' id='dropdown' class='form-control input-lg'>"
								+ "<option value='problemSearch'>Problem Ara</option>"
								+ "<option value='solutionSearch'>��z�m Ara</option>"
								+ "<option value='tagSearch'>Etiket Ara</option>"
								+ "</select>"
								+ "</span>"								
								+ "<span class='input-group-btn'>"
									+ "<button type='submit' class='btn input-lg' type='button' style='background-color:#004892; color:#FFFFFF;'><i class='fa fa-search' aria-hidden='true'></i></button>"
								+ "</span>"
									
						+ "</div>"
						+ "</form>"

					+ "</div>"
					+ "<div class='col-md-2' style='margin-top:32px; text-align:right;'>" + (currentDate)
					+ "</div>"
				+ "</div>"
						
					+ "<p style='height:10px;'></p>"
					
					+ "<div class='row'>"
						+ "<div class='col-md-4'>"
							+ "<div class='panel panel-default' style='background-color:#f8f7ff;'>"
								+ "<div class='panel-body'>"
									+ "<button class='btn form-control input-lg' type='button' style='font-weight:bold; font-size:15px; font-family:system-ui; background-color:#004892; color:#FFFFFF;' data-toggle='modal' data-target='#myModalprob'> YEN� PROBLEM EKLE </button>"
									+ "<p>&nbsp;</p>"
									+ "<h4 style='font-weight:bold; text-align:center; font-size:20px; font-family:system-ui;'>SON EKLENEN HATALAR</h4>");
										out.println("<ul style='font-size:20px; font-family:serif;'>");
											for (int i = 0; i < resultlast.size(); i++) { out.println("<li><a href='detayServlet?id=" + resultlast.get(i).getProbID() +"'>" + resultlast.get(i).getProblem().substring(0,20) + "...</a></li>"); }
										out.println("</ul>");
						out.print("</div>"
							+ "</div>"
						+ "</div>"
						
						+ "<div class='col-md-8'>"
							+ "<div class='panel panel-default' style='background-color:#f8f7ff;'>"
							+ "<div class='panel-body'>"
								+ "<h4 style='font-weight:bold; text-align:left; font-size:20px; font-family:system-ui;'>�STAT�ST�KLER</h4>");
//										for (int i = 0; i < resultlast.size(); i++) { out.println("<li><a href='#'>" + resultlast.get(i).getProblem().substring(0,20) + "...</a></li>"); }
										
						
						out.print("<div class='row'>"
									+ "<div class='col-md-12' style='text-align:center;'>"
									+ "</div>"
								+ "</div>");
						
						out.println("<p style='height:17px;'></p>");
						
						out.print("<div class='row' style='text-align:center;'>"
									+ "<div class='col-md-4' style='color:#D61515;'>"
										+ "<i class='fa fa-exclamation-triangle fa-5x' aria-hidden='true'></i><br/>"
										+ "<b>TOPLAM HATA</b><br/>");
						
							out.println("<b style='font-size:25px;'>" + resultcounterror.get("errorCount") + "</b>");
						
							out.print("</div>"
									+ "<div class='col-md-4' style='color:#178217;'>"
										+ "<i class='fa fa-check-square fa-5x' aria-hidden='true'></i><br/>"
										+ "<b>��Z�LEN HATA</b><br/>");
							out.println("<b style='font-size:25px;'>" + resultcounterror.get("solutionCount") + "</b>");

							out.print("</div>"
									+ "<div class='col-md-4' style='color:#004892;'>"
										+ "<i class='fa fa-pencil-square fa-5x' aria-hidden='true'></i><br/>"
										+ "<b>BEKLEYEN HATA</b><br/>");
										out.println("<b style='font-size:25px;'>" + resultcounterror.get("pandingCount") + "</b>");
				
				out.println("<p style='height:15px;'></p>");
				
							out.print("</div>"
									+ "</div>"
									+ "</div>"
								+ "</div>");
						
						out.print("<div class='row'>"
							+ "<div class='col-md-2'>"	
							+ "<a href='DetayTag'><button class='btn form-control input-lg' type='button' style='font-weight:bold; font-size:15px; font-family:system-ui; height:100px; background-color:#004892; color:#FFFFFF;'> ET�KET </br> ��LEMLER� </button></a>"
							+ "</div>"
							+ "<div class='col-md-10'>");
						
						out.print("<div class='owl-carousel owl-theme' >");
//						out.println(pc.readByTagID(id).getTag());
						 for (int i = 0; i < resultlasttag.size(); i++) { 
								 out.print(" <a href='TagSearch'><div class='item'>#"+ resultlasttag.get(i).getTag() + "</div></a>");
							 }
						out.print("</div>"
							+ "</div>");
							 
							 out.print("</div>"
						+ "</div>");
						
					out.print("</div>"			
				
				+ "</div>");
		
				
				
		
				 
				 
					out.print("  <div class='modal fade' id='myModalprob' role='dialog'>" + 
							"    <div class='modal-dialog'>" + 
							"      <div class='modal-content'>" + 
							"        <div class='modal-header'>" + 
							"          <button type='button' class='close' data-dismiss='modal'>&times;</button>" + 
							"          <h4 class='modal-title'><b style='color:#004892;'>PROBLEM EKLE</b></h4>" + 
							"        </div>" + 
							"        <div class='modal-body'>" + 
							"			<p>" +

		"<div class='row' style='text-align:center;'>"
				+"<div class='col-md-12'>"
					+ "<textarea placeholder='K�saca Sorununuzu Yaz�n�z..' class='form-control' rows='4' style='resize: vertical;' id='problemdeger'></textarea><br/>"
				+ "</div>"
		+ "</div>" +
				
		"<div class='row' style='text-align:center;'>"
				+"<div class='col-md-12'>"
					+ "<textarea placeholder='E�er Bir ��z�m�n�z Varsa Yaz�n�z..' class='form-control' rows='4' style='resize: vertical;' id='cozumdeger'></textarea><br/>"
				+ "</div>"
		+ "</div>" +
							
							
							"			</p>" + 
							"        </div>" + 
							"        <div class='modal-footer'>" + 
							"          <button type='button' class='btn btn-primary soln' name='soldznlbtn' data-dismiss='modal' onClick='addFunction(\"problemdeger\",\"cozumdeger\")'>KAYDET</button>" + 
							"          <button type='button' class='btn btn-default' data-dismiss='modal'>�PTAL</button>" + 
							"        </div>" + 
							"      </div>" + 
							"    </div>" + 
							"  </div>");
				 
				 


		out.println("<div style='height:10px; width:100%; background-color:#004892; margin-top:129px;'></div>");
				
		out.println("<script>"
				+ "var owl = $('.owl-carousel');\r\n" + 
				"owl.owlCarousel({\r\n" + 
				"    items:20,\r\n" + 
				"    loop:true,\r\n" + 
				"    margin:10,\r\n" + 
				"    autoplay:true,\r\n" + 
				"    autoplayTimeout:2000,\r\n" + 
				"    autoplayHoverPause:true,\r\n" +
				"  autoWidth:true\r\n" + 
				"});\r\n" + 
				"$('.play').on('click',function(){\r\n" + 
				"    owl.trigger('play.owl.autoplay',[1000])\r\n" + 
				"})\r\n" + 
				"$('.stop').on('click',function(){\r\n" + 
				"    owl.trigger('stop.owl.autoplay')\r\n" + 
				"})</script>");
		
		out.println("</body>");
		out.println("</html>");
	
	

	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

	}

}
