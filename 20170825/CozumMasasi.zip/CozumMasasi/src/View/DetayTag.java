package View;



import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Controller.ProblemsController;
import Controller.TagsController;
import Entity.Problem;
import Entity.Tag;

/**
 * Servlet implementation class DetayEtiket
 */
@WebServlet("/DetayTag")
public class DetayTag extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DetayTag() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy, EEEE");
        String currentDate = sdf.format(new Date());
	
		PrintWriter out = response.getWriter();
		ProblemsController pc = new ProblemsController();
		TagsController tc = new TagsController();

		ArrayList<Problem> result = pc.readAll();
//		ArrayList<Problem> resultlast = pc.readlast();
//		ArrayList<Problem> resultinstantprob = pc.searchInstant(kelime);
		HashMap<String,Integer> resultcounterror = pc.statisticErrors();
		ArrayList<Tag> resultlastyuz = tc.readlastyuz();
		
		

		out.println("<html><head>"
				
				+ "<!-- CSS FOLDERS -->"
				+ "<link href='plugins/bootstrap/css/bootstrap.min.css' rel='stylesheet'>"
				+ "<link href='plugins/font-awesome/css/font-awesome.min.css' rel='stylesheet'>"
				+ "<link href='plugins/owl-carousel/assets/owl.carousel.css' rel='stylesheet'>"
				+ "<link href='plugins/owl-carousel/assets/owl.theme.default.css' rel='stylesheet'>"
				+ "<link href='plugins/style.css' rel='stylesheet'>"
				
				+ "<!-- JS FOLDERS -->"
				+ "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>"
				+ "<script src='plugins/owl-carousel/owl.carousel.min.js' rel='stylesheet'></script>"
				+ "<script src='plugins/bootstrap/js/bootstrap.min.js'></script>");
		

		out.print("<script>"			
		
		+	"function addFunction(addtag,addtagc) {"
		+	"var ekrandanGelenTag = $('.' + addtagc).val();"
		
			   +" if ( ekrandanGelenTag==''){"
		 			+"alert(\"ET�KET BO� BIRAKILAMAZ\");}"
			   +"else{"		
				   	+	"$.post('IsTagExist', {"
			 		+	"newEtiket: ekrandanGelenTag,"	
				   	+   "}," 	
			 		   
			 		+	"function(result){"
			 		+ "var donendeger=$.parseJSON(result);"
			 				+"if(donendeger.donendeger==true){"
			 					+"alert('Bu Etiket Zaten Var!');}"
			 				
			 				+"else{"
			 					+	"$.post(addtag, {"
						 		+	"newEtiket: ekrandanGelenTag,"				 	
						 		+	"},"
						 		+	"function(result){"		 		
						 		+	"$('.basarili').css({'display': 'block'}).delay(2000).slideUp();"
					 			+	"setTimeout(function(){"
					 			+	"location.reload();},2500);"
						 		+	"}\n"
				 			+")}"
					+	"}"
					
				 +	")}"
		 + " };"
						 
				 
				+	"function deleteFunction(deleteItem,deleteId) {"
				+	"var ekrandanGelenId = deleteId;"
				+	"if(deleteItem=='DeleteTag'){ tanim='ET�KET�'; }"
				+	"if (confirm(tanim + ' S�LMEK �ZERES�N�Z!!')) {"
				
				+	"$.post(deleteItem , {"
				 		+	"id: ekrandanGelenId,"
				 		+	"},"
				 		+	"function(result){"
//			 				+	"alert('Kay�t Silindi.');"
				 		
				 			+	"$('.basarili').css({'display': 'block'}).delay(2000).slideUp();"
				 			+	"setTimeout(function(){"
				 			+	"location.reload(); },2500);"
				 			
				 			+	"},"
				 		+	")"
				 + "}else{ alert('�PTAL ED�LD�..'); }"
				 +"};"	
				 
				 
				+	"function updateFunction(updateItem,updateNew,updateNewId,eskiveri,dznlbtngr) {"
				+	"var ekrandanGelenNew = $('.' + updateNew).val();"
				+	"var ekrandanGelenId = updateNewId;"
				+	"$.post(updateItem , {"
				 		+	"id: ekrandanGelenId,"
				 		+	"newVal: ekrandanGelenNew"
				 		+	"},"
				 		+	"function(result){"
				 			+ 	"$('.' + eskiveri).html(ekrandanGelenNew);"
							+	"$('.' + eskiveri).toggle();"
							+	"$('.' + updateNew).hide();"
							+	"$('.' + dznlbtngr).toggle();"
			//	 			+	"alert('Kay�t G�ncellendi.');"
							
//				 			+	"$('.basarili').css({'display': 'block'}).delay(2000).slideUp();"
						+	"location.reload();"
				 		+	"},"
				 +	")};"
				 		
					+ "$(document).ready(function(){"
					+ "$('textarea').hide();"
					+ "$('.etiketeklenecektext').toggle();"
						+ "$('button.tagdznlbtn').hide();"
						
							+ "$.ortamgoster = {"
								+ "duzenle : function(dznl,dznlo,dznlbtngr){"
									+ "$('.' + dznl).toggle();"
									+ "$('.' + dznlo).hide();"
									+ "$('.' + dznlbtngr).hide();"
									+ "$('.gizlialan').css({'visibility': 'visible'});"
								+ "}"
							+ "};"
								
							+ "$.ortamiptal = {"
							+ "iptal : function(dznl,dznlo,dznlbtngr){"
								+ "$('.' + dznl).hide();"
								+ "$('.' + dznlo).toggle();"
								+ "$('.' + dznlbtngr).toggle();"
							+ "}"
						+ "};"

					+ "});"
				 								
				+ "</script>");
		
		
out.println("</head><body><div class='basarili' style='display:none; position:fixed; z-index:1; width:100%; height:50px; background-color:#178217; color:#FFFFFF; text-align:center; padding-top:10px; font-size:25px;'><b><i class='fa fa-check' aria-hidden='true'></i> BA�ARILI</b></div>");
		out.println("<div style='height:10px; width:100%; background-color:#004892;'></div>");
		out.println("<div class='container' style='margin-top:20px;'>"
					+ "<div class='row'>"
						+ "<div class='col-md-4'>"
							+ "<a href='index.html'><img src='Images/cozummasasilogo.png' style='width:350px; height:auto;'></a>"
						+ "</div>"

						+ "<div class='col-md-6' style='margin-top:20px;'>"
						+ "<form action='DetaySearch' method='GET'>"

						+ "<div class='input-group'>"

						+ "<input type='text' class='form-control input-lg' placeholder='Problem, ��z�m ve ya etiket aray�n' name='search'>"
						
								+ "<span class='input-group-btn' style='width:175px;'>"
								+ "<select name='cat' id='dropdown' class='form-control input-lg'>"
								+ "<option value='problemSearch'>Problem Ara</option>"
								+ "<option value='solutionSearch'>��z�m Ara</option>"
								+ "<option value='tagSearch'>Etiket Ara</option>"
								+ "</select>"
								+ "</span>"
								
								+ "<span class='input-group-btn'>"
									+ "<button type='submit' class='btn input-lg' type='button' style='background-color:#004892; color:#FFFFFF;'><i class='fa fa-search' aria-hidden='true'></i></button>"
								+ "</span>"
									
						+ "</div>"
						+ "</form>"

					+ "</div>"
					+ "<div class='col-md-2' style='margin-top:32px; text-align:right;'>" + (currentDate)
					+ "</div>"
				+ "</div>"
						
					+ "<p style='height:10px;'></p>"
					
					
			+ "<div class='panel panel-default' style='background-color:#f8f7ff;'>"
				+ "<div class='row'>"	
					+ "<div class='panel-body'>"
						+ "<div class='col-md-4'>"					
								+ "<button class='btn form-control input-lg' type='button' style='font-weight:bold; font-size:15px; font-family:system-ui; background-color:#004892; color:#FFFFFF;' data-toggle='modal' data-target='#myModaladdtag'> YEN� ET�KET EKLE </button>"
						+ "</div>"
						+ "<div class='col-md-8'>"
							

+ "<form action='DetayTagSearch' method='GET'>"

+ "<div class='input-group'>"

+ "<input type='text' class='form-control input-lg' placeholder='Etiket aray�n' name='search'>"
									
		+ "<span class='input-group-btn'>"
			+ "<button type='submit' class='btn input-lg' type='button' style='background-color:#004892; color:#FFFFFF;'>F�LTRELE &nbsp<i class='fa fa-filter' aria-hidden='true'></i></button>"
		+ "</span>"
			
+ "</div>"
+ "</form>"

						+ "</div>"	
					+ "</div>"
				+ "</div>"
			+ "</div>"
						);
								
		out.print("<div class='panel-body'>"); 	
				for (int i = 0; i < resultlastyuz.size(); i++) { 
					 out.print("<div class='item' style='float:left; margin-left:8px; margin-top:8px;'>"
					 		+ "<span class='tago"+ i +"'>#"+ resultlastyuz.get(i).getTag() + "</br>"
										 +"<i class='fa fa-pencil fa-7x' aria-hidden='true' style='color:#6fba00;'  onClick='$.ortamgoster.duzenle(\"tagn" + i + "\",\"tago" + i + "\", \"tagf"+ i +"\")'></i>"
//										onClick='$.ortamgoster.duzenle(\"textn\",\"texto\", \"textf\")'
								+ "&nbsp;&nbsp;"
								
+ "<i class='fa fa-times fa-7x' aria-hidden='true' style='color:#D61515;' onClick='deleteFunction(\"DeleteTag\",\"" + resultlastyuz.get(i).getTagID() + "\")'></i></span>"

//								 onClick='deleteFunction(\"DeleteProblem\",\"" + pc.readByTagID(id).getTagID() + "\")'
						
					 		+	"<div class='gizlialan' style='visibility:hidden;'>"
							+ "<textarea name='newTag' class='form-control tagn"+ i +"' rows='2' style='width:130px; height:40px;'>" + resultlastyuz.get(i).getTag() + "</textarea>"
					
							 +	"</div>"
				
					+	"<div class='btn-group gizlialan' style='visibility:hidden;'>"
						+	"<button type='submit' class='btn btn-success btn-sm  tagn"+ i +" tagdznlbtn' name='tagdznlbtn' value='KYDT' ;' onClick='updateFunction(\"UpdateTag\",\"tagn"+ i +"\",\""+ resultlastyuz.get(i).getTagID() + "\", \"tago"+ i +"\", \"tagf"+ i +"\")'>KYDT</button>"
						+	"<button type='submit' class='btn btn-danger btn-sm  tagn"+ i +" tagdznlbtn' name='tagdznlbtn' value='�PTL' onClick='$.ortamiptal.iptal(\"tagn" + i + "\",\"tago" + i + "\", \"tagf"+ i +"\")'>�PTL</button>"
						+ "</div>"
						
						+	"</div>");
				 }
			
				out.print( "</div>"
				+ "</div>");
		
					out.print("</div>"						
				+ "</div>");
							
					out.print("</div>"				
				+ "</div>"); 
			
					out.print("  <div class='modal fade' id='myModaladdtag' role='dialog'>" + 
								"    <div class='modal-dialog'>" + 
								"      <div class='modal-content'>" + 
								"        <div class='modal-header'>" + 
								"          <button type='button' class='close' data-dismiss='modal'>&times;</button>" + 
								"          <h4 class='modal-title'><b style='color:#004892;'>ET�KET EKLE</b></h4>" + 
								"        </div>" + 
								"        <div class='modal-body'>" + 
								"          <p>"
								+ "<textarea class='form-control etiketeklenecektext addtag' rows='4' style='resize:vertical;' placeholder='Bir etiket giriniz..'></textarea>"
								+ "</p>" + 
								"        </div>" + 
								"        <div class='modal-footer'>" + 
								"          <button type='button' class='btn btn-primary' data-dismiss='modal' onClick='addFunction(\"AddTag\",\"addtag\")'>KAYDET</button>" + 
								"          <button type='button' class='btn btn-default' data-dismiss='modal'>�PTAL</button>" + 
								"        </div>" + 
								"      </div>" +
								"     </div>" +
								"    </div>" +
								"  </div>");


		out.println("<div style='height:10px; width:100%; background-color:#004892; margin-top:126px;'></div>");
		
		
		out.println("</body>");
		out.println("</html>");
	
	
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}