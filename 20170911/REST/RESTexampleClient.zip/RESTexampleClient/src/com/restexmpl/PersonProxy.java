package com.restexmpl;

public class PersonProxy implements com.restexmpl.Person {
  private String _endpoint = null;
  private com.restexmpl.Person person = null;
  
  public PersonProxy() {
    _initPersonProxy();
  }
  
  public PersonProxy(String endpoint) {
    _endpoint = endpoint;
    _initPersonProxy();
  }
  
  private void _initPersonProxy() {
    try {
      person = (new com.restexmpl.PersonServiceLocator()).getPerson();
      if (person != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)person)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)person)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (person != null)
      ((javax.xml.rpc.Stub)person)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.restexmpl.Person getPerson() {
    if (person == null)
      _initPersonProxy();
    return person;
  }
  
  public java.lang.String getName() throws java.rmi.RemoteException{
    if (person == null)
      _initPersonProxy();
    return person.getName();
  }
  
  public void setName(java.lang.String name) throws java.rmi.RemoteException{
    if (person == null)
      _initPersonProxy();
    person.setName(name);
  }
  
  public int getAge() throws java.rmi.RemoteException{
    if (person == null)
      _initPersonProxy();
    return person.getAge();
  }
  
  public void setAge(int age) throws java.rmi.RemoteException{
    if (person == null)
      _initPersonProxy();
    person.setAge(age);
  }
  
  public java.lang.String getGender() throws java.rmi.RemoteException{
    if (person == null)
      _initPersonProxy();
    return person.getGender();
  }
  
  public void setGender(java.lang.String gender) throws java.rmi.RemoteException{
    if (person == null)
      _initPersonProxy();
    person.setGender(gender);
  }
  
  
}