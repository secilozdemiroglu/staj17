/**
 * Person.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.restexmpl;

public interface Person extends java.rmi.Remote {
    public java.lang.String getName() throws java.rmi.RemoteException;
    public void setName(java.lang.String name) throws java.rmi.RemoteException;
    public int getAge() throws java.rmi.RemoteException;
    public void setAge(int age) throws java.rmi.RemoteException;
    public java.lang.String getGender() throws java.rmi.RemoteException;
    public void setGender(java.lang.String gender) throws java.rmi.RemoteException;
}
