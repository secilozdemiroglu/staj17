package com.restexmpl;

import java.util.ArrayList;

import javax.ws.rs.GET; 
import javax.ws.rs.Path; 
import javax.ws.rs.Produces; 
import javax.ws.rs.core.MediaType; 


public class Persons {
	 @GET 
	 @Path("persons")
	 @Produces(MediaType.APPLICATION_XML)
	public Person[] getAllPersons() {
		ArrayList<Person> list = new ArrayList();
		Person[] plist = new Person[2];

		Person p1 = new Person();
		Person p2 = new Person();

		p1.setName("Name1");
		p1.setAge(1);
		p1.setGender("Female");

		p2.setName("Name2");
		p2.setAge(2);
		p2.setGender("Male");

		list.add(p1);
		list.add(p2);
		
		
		plist[0] = p1;
		plist[1] = p2;

		return plist;
	}
}
