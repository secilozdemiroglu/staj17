package com.secil.client;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.client.urlconnection.HttpURLConnectionFactory;
import com.sun.jersey.client.urlconnection.URLConnectionClientHandler;

public class JerseyClientPost {

	public static void main(String[] args) {

		
		
		restCall();
//		System.out.println(System.getProperties().containsKey("http.proxyHost"));
		//restCall2();
	}

	public static void restCall() {
		try {
			ClientConfig config = new DefaultClientConfig();
			Client client = new Client(new URLConnectionClientHandler(new HttpURLConnectionFactory() {
				Proxy p = null;

				@Override
				public HttpURLConnection getHttpURLConnection(URL url) throws IOException {
					if (p == null) {
						if (System.getProperties().containsKey("http.proxyHost")) {
							p = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(System.getProperty("http.proxyHost"),
									Integer.getInteger("http.proxyPort", 80)));
						} else {
//							p = Proxy.NO_PROXY;
							
							p = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("pars", 3128));
						}
					}
					return (HttpURLConnection) url.openConnection(p);
				}
			}), config);

			WebResource webResource = client.resource("https://jsonplaceholder.typicode.com/posts");

			ClientResponse response = webResource.type("application/json").post(ClientResponse.class, "");

			if (response.getStatus() != 201) {
				throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}

			System.out.println("Output from Server .... \n");
			String output = response.getEntity(String.class);
			System.out.println(output);

		} catch (Exception e) {

			e.printStackTrace();

		}
	}



}
