package Entity;

public class Solution {
	int SolutionsID;
	String solution;
	int ProbID;
	
	public int getProbID() {
		return ProbID;
	}
	public void setProbID(int probID) {
		ProbID = probID;
	}
	public int getSolutionsID() {
		return SolutionsID;
	}
	public void setSolutionsID(int solutionsID) {
		SolutionsID = solutionsID;
	}
	public String getSolution() {
		return solution;
	}
	public void setSolution(String solution) {
		this.solution = solution;
	}
}
