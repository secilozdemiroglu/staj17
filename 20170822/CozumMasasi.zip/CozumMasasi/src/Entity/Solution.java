package Entity;

public class Solution {
	int SolutionsID;
	String solution;
	int probId;
	
	public int getProbId() {
		return probId;
	}
	public void setProbId(int probId) {
		this.probId = probId;
	}
	public int getSolutionsID() {
		return SolutionsID;
	}
	public void setSolutionsID(int solutionsID) {
		SolutionsID = solutionsID;
	}
	public String getSolution() {
		return solution;
	}
	public void setSolution(String solution) {
		this.solution = solution;
	}
}
