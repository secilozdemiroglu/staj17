package Controller;

import java.util.ArrayList;

import Entity.Tag;
import Model.TagsModel;

public class TagsController extends Controller {
	int TagID;
	String tag;
	
	public TagsModel tm= new TagsModel();
	
	public ArrayList<Tag> readlast(){
		return tm.readlast();
	}
	
	
	public int getTagID() {
		return TagID;
	}
	public void setTagID(int tagID) {
		TagID = tagID;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
}
