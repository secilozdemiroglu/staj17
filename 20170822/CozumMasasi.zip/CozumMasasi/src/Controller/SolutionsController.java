package Controller;

import java.sql.SQLException;
import java.util.ArrayList;

import Entity.Solution;
import Model.SolutionsModel;

public class SolutionsController extends Controller {

	SolutionsModel sm = new SolutionsModel();

	public ArrayList<Solution> readByID(int id) {
		try {
			return sm.readByID(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void updateSolution(Solution sltion) {
		try {
			sm.update(sltion);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void deleteSolution(int sltion) {
		try {
			sm.deleteSolution(sltion);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public void addsolution(Solution sltion){
		try {
			sm.addsolution(sltion);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
}
