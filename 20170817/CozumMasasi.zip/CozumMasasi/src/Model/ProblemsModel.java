package Model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import Entity.Problem;

public class ProblemsModel extends Model {

	public void add(Problem prblm) throws SQLException {
		stmt = con.prepareStatement("INSERT INTO problems VALUES(NULL,?,NOW())");
		stmt.setString(1, prblm.getProblem());

		int rs = stmt.executeUpdate();
		System.out.println("Problem Eklendi");
	}

	public void update(Problem prblm) throws SQLException {
		stmt = con.prepareStatement("UPDATE problems SET problem=? WHERE ProbID=?");
		stmt.setString(1, prblm.getProblem());
		stmt.setInt(2, prblm.getProbID());

		int rs = stmt.executeUpdate();
		System.out.println("Problem G�ncellendi");
	}

	public Problem readByID(int id) throws SQLException {
		stmt = con.prepareStatement("SELECT * FROM problems WHERE ProbID=?");
		stmt.setInt(1, id);
		ResultSet rs = stmt.executeQuery();

		if (rs.next()) {
			Problem problem = new Problem();
			problem.setProbID(rs.getInt("ProbID"));
			problem.setProblem(rs.getString("problem"));
			return problem;
		}
		return null;
	}

	public ArrayList<Problem> readAll() {
		ArrayList<Problem> list = new ArrayList();
		ResultSet rs;
		try {
			stmt = con.prepareStatement("SELECT * FROM problems");
			rs = stmt.executeQuery();

			while (rs.next()) {
				Problem p = new Problem();
				p.setProblem(rs.getString("problem"));
				p.setDate(rs.getDate("date"));
				list.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	public ArrayList<Problem> readlast() {
		ArrayList<Problem> list = new ArrayList();
		ResultSet rs;
		try {
			stmt = con.prepareStatement("SELECT * FROM problems ORDER BY ProbID DESC LIMIT 10");
			rs = stmt.executeQuery();

			while (rs.next()) {
				Problem p = new Problem();
				p.setProblem(rs.getString("problem"));
				p.setDate(rs.getDate("date"));
				list.add(p);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	public HashMap statisticErrors() {
		HashMap<String, Integer> sterorr = new HashMap<String, Integer>();
		ResultSet rs;
		try {
			stmt = con.prepareStatement("SELECT  COUNT(*) From problems");
			rs = stmt.executeQuery();

			while (rs.next()) {
				sterorr.put("errorCount", rs.getInt(1));
			}
			
			stmt = con.prepareStatement("SELECT  COUNT(DISTINCT(ProbID)) From solutions ");
			rs = stmt.executeQuery();

			while (rs.next()) {
				sterorr.put("solutionCount", rs.getInt(1));
			}
			
			stmt = con.prepareStatement("SELECT  COUNT(*) FROM problems WHERE problems.ProbID NOT IN(SELECT ProbID FROM solutions)");
			rs = stmt.executeQuery();

			while (rs.next()) {
				sterorr.put("pandingCount", rs.getInt(1));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return sterorr;
	}

	public void delete(int id) throws SQLException {
		stmt = con.prepareStatement("DELETE FROM problems WHERE ProbID=?");
		stmt.setInt(1, id);
		int rs = stmt.executeUpdate();

		System.out.println("Silindi");
	}
}
