package Controller;

public class SolutionsController extends Contoller {

	int SolutionID;
	String solution;

	public int getSolutionID() {
		return SolutionID;
	}

	public void setSolutionID(int solutionID) {
		SolutionID = solutionID;
	}

	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}

}
