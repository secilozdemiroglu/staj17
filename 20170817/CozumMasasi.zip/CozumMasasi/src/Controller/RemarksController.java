package Controller;

public class RemarksController extends Contoller {
	int MarkID;
	String remark;

	public int getMarkID() {
		return MarkID;
	}

	public void setMarkID(int markID) {
		MarkID = markID;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
