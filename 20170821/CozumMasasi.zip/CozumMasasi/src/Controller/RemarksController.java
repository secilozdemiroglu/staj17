package Controller;

import java.sql.SQLException;
import java.util.ArrayList;

import Entity.Remark;
import Model.RemarksModel;

public class RemarksController extends Controller {

	RemarksModel rm=new RemarksModel();
	
	public ArrayList<Remark> readByProbID(int id) {
		try {
			return rm.readByProbID(id);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void updateRemark(Remark remark) {
		try {
			rm.updateRemark(remark);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
}
