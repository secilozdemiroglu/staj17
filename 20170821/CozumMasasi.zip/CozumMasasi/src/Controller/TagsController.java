package Controller;

public class TagsController extends Controller {
	int TagID;
	String tag;
	
	public int getTagID() {
		return TagID;
	}
	public void setTagID(int tagID) {
		TagID = tagID;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
}
