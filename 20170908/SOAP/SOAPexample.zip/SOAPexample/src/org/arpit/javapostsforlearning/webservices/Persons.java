package org.arpit.javapostsforlearning.webservices;

import java.util.ArrayList;

import javax.jws.WebService;

@WebService
public class Persons {

	public Person[] getAllPersons() {

		ArrayList<Person> list = new ArrayList();
		Person[] plist = new Person[2];

		Person p1 = new Person();
		Person p2 = new Person();

		p1.setName("Name1");
		p1.setAge(1);
		p1.setGender("Female");

		p2.setName("Name2");
		p2.setAge(2);
		p2.setGender("Male");

		list.add(p1);
		list.add(p2);
		
		
		plist[0] = p1;
		plist[1] = p2;

		return plist;
	}

}
