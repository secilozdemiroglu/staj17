package org.arpit.javapostsforlearning.webservices;

public class PersonsSOAP {
	
 
	
}
