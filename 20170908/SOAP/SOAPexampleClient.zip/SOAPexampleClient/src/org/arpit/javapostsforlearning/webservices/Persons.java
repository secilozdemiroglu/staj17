/**
 * Persons.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.arpit.javapostsforlearning.webservices;

public interface Persons extends java.rmi.Remote {
    public java.lang.Object[] getAllPersons() throws java.rmi.RemoteException;
}
