/**
 * PersonsService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.arpit.javapostsforlearning.webservices;

public interface PersonsService extends javax.xml.rpc.Service {
    public java.lang.String getPersonsAddress();

    public org.arpit.javapostsforlearning.webservices.Persons getPersons() throws javax.xml.rpc.ServiceException;

    public org.arpit.javapostsforlearning.webservices.Persons getPersons(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
