package com.mkyong.common;

public class Main {

	public static void main(String[] args) {
		
		UserData u = new UserData();
		u.getData();
		
	}

}
