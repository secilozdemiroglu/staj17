package com.mkyong.common;

import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import com.mkyong.common.Database;

@ManagedBean(name = "calldb")
@ApplicationScoped
public class CallDb {
    
	private final static String[] colors;
     
    static {
        colors = new String[10];
        colors[0] = "Black";
        colors[1] = "White";
        colors[2] = "Green";
        colors[3] = "Red";
        colors[4] = "Blue";
        colors[5] = "Orange";
        colors[6] = "Silver";
        colors[7] = "Yellow";
        colors[8] = "Brown";
        colors[9] = "Maroon";
         
    }
     
	
	  public List<Database> createColors(int size) {
	        List<Database> list = new ArrayList<Database>();
	        for(int i = 0 ; i < size ; i++) {
	            list.add(new Database(getRandomId(), getRandomColor()));
	        }
	        
	        return list;
	    }
	
	  private int getRandomId() {
		  return (int) (Math.random() * 10);
      }
	  
	  private String getRandomColor() {
	        return colors[(int) (Math.random() * 10)];
	    }
       
}

