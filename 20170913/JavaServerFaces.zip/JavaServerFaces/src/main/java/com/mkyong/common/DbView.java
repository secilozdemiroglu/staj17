package com.mkyong.common;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import com.mkyong.common.Database;
import com.mkyong.common.CallDb;

@ManagedBean(name="dbView")
@ViewScoped
public class DbView implements Serializable{

	private static final long serialVersionUID = 1L;

	private List<Database> color;
    
    @ManagedProperty("#{calldb}")
    private CallDb service;
 
    @PostConstruct
    public void init() {
        color = service.createColors(10);
    }
     
    public List<Database> getColors() {
        return color;
    }
 
    public void setService(CallDb service) {
        this.service = service;
    }
}
