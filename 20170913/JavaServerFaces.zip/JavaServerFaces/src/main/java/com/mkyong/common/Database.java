package com.mkyong.common;

public class Database {
     
    int id;
    String text;
    
	public Database(int randomId, String randomColor) {
		this.id = randomId;
		this.text = randomColor;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
    

 
    
}
